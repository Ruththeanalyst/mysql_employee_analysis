-- Advanced analysis using window functions
USE parks_and_recreation;

SELECT dem.first_name, dem.last_name, dem.gender, sal.salary,
       RANK() OVER (PARTITION BY dem.gender ORDER BY sal.salary DESC) AS salary_rank
FROM employee_demographics dem
JOIN employee_salary sal
  ON dem.employee_id = sal.employee_id;
