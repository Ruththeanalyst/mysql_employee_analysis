-- String-based analysis
USE parks_and_recreation;

SELECT first_name, last_name, CONCAT(first_name, ' ', last_name) AS full_name
FROM employee_demographics;
