# MySQL Employee Analysis

According to the analysis performed on the `parks_and_recreation` dataset, this project explores employee demographics, salary distribution, and ranking patterns using MySQL.

## Objectives
- Perform exploratory data analysis using SELECT statements
- Apply filtering logic with WHERE, LIKE, AND/OR
- Generate insights using GROUP BY and HAVING
- Use advanced SQL features such as CTEs, subqueries, and window functions
- Demonstrate analytical thinking using clean, well-documented SQL

## Tools
- MySQL
- SQL (CTEs, Window Functions, Subqueries)

## Dataset
Sample dataset: `parks_and_recreation`

## Structure
Each SQL file focuses on a specific analytical concept, progressing from basic to advanced.

## Author
Your Name
