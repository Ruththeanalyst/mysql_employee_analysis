-- Result limiting and aliasing
USE parks_and_recreation;

SELECT *
FROM employee_demographics
ORDER BY age DESC
LIMIT 3;

SELECT gender, AVG(age) AS avg_age
FROM employee_demographics
GROUP BY gender;
