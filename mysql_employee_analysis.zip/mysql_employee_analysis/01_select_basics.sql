-- Exploratory analysis using SELECT statements
USE parks_and_recreation;

SELECT *
FROM employee_demographics;

SELECT first_name, last_name, age, (age + 20) * 10 AS computed_value
FROM employee_demographics;

SELECT DISTINCT first_name, gender
FROM employee_demographics;
