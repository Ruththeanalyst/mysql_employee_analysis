-- Filtering analysis using WHERE, LIKE, AND/OR
USE parks_and_recreation;

SELECT *
FROM employee_demographics
WHERE birth_date > '1985-01-01'
  AND gender = 'male';

SELECT *
FROM employee_demographics
WHERE first_name LIKE '%er%';
