-- Analytical modeling using CTEs
USE parks_and_recreation;

WITH salary_cte AS (
    SELECT dem.gender, AVG(sal.salary) AS avg_salary
    FROM employee_demographics dem
    JOIN employee_salary sal
      ON dem.employee_id = sal.employee_id
    GROUP BY dem.gender
)
SELECT *
FROM salary_cte;
